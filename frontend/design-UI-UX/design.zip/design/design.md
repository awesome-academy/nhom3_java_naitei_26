# DESIGN SPECIFICATION — EXPENSE MANAGEMENT SYSTEM

## 1. Mục tiêu
- Thiết kế web app quản lý chi tiêu hoàn chỉnh, không chỉ một Dashboard.
- Phải tạo nhiều màn hình riêng biệt và liên kết bằng navigation.
- Mỗi sidebar item, button CRUD và row chính phải dẫn tới màn hình/action tương ứng.
- Thiết kế phải export tốt sang Figma và khả thi với Next.js + Tailwind CSS.
- Hệ thống gồm hai vùng tách biệt: User và Admin.
- Backend context: Java Spring Boot REST API, MySQL, Docker.
- Không tự thêm nghiệp vụ phức tạp ngoài specification.
- Ưu tiên professional, clean, modern, data-first, dễ dùng và dễ code.

## 2. Visual Direction
- Modern financial SaaS dashboard.
- Light theme.
- Background #F8FAFC.
- Surface #FFFFFF.
- Border #E2E8F0.
- Text primary #0F172A.
- Text secondary #475569.
- Primary #2563EB.
- Success #16A34A.
- Warning #D97706.
- Danger #DC2626.
- Font ưu tiên Inter.
- Radius phổ biến 8–12px.
- Spacing theo hệ 4px.
- Shadow nhẹ, ưu tiên border.
- Không glassmorphism nặng.
- Không gradient quá mức.
- Không thiết kế như landing page.
- Table, form, KPI và chart phải dễ đọc.

## 3. Responsive Base
- Desktop reference: 1440px.
- Tablet reference: 768px.
- Mobile reference: 390px.
- Sidebar desktop khoảng 240–256px.
- Topbar khoảng 64–72px.
- Main gutter khoảng 24–32px.
- Desktop grid 12 columns.
- Mobile navigation dùng drawer.
- Mobile form dùng 1 column.
- Mobile chart full width.
- User table nên chuyển thành compact list/card khi cần.
- Admin table có thể horizontal scroll có kiểm soát.
## 4. User Application Shell
- Logo và tên Expense Management ở sidebar.
- Navigation: Dashboard.
- Navigation: Expenses.
- Navigation: Incomes.
- Navigation: Categories.
- Navigation: Budgets.
- Navigation: Reports.
- Navigation: Import / Export.
- Active item phải nổi bật.
- Mỗi item có icon.
- Topbar có breadcrumb/page context.
- Topbar có avatar/user menu.
- User menu có Logout.
- Mỗi navigation item mở page riêng.
- Không dồn tất cả module vào Dashboard.

## 5. Admin Application Shell
- Admin dùng layout riêng nhưng cùng Design System.
- Có dấu hiệu rõ đây là Admin area.
- Navigation: Dashboard.
- Navigation: Users.
- Navigation: Categories.
- Navigation: Budget Templates.
- Navigation: Expenses.
- Navigation: Incomes.
- Navigation: Activity Logs.
- Navigation: Import / Export.
- Mỗi navigation item mở page riêng.
- User và Admin không dùng chung navigation config.
## 6. U01 — User Login
- Màn hình Login riêng.
- Logo/tên hệ thống.
- Heading Sign in.
- Email input.
- Password input.
- Sign in button.
- Validation state.
- Invalid credentials state.
- Loading state.
- Login thành công chuyển U02 Dashboard.

## 7. U02 — User Dashboard
- Header Dashboard.
- Hiển thị tháng hiện tại.
- Primary CTA Add new expense.
- KPI Total Income.
- KPI Total Expense.
- KPI Remaining Balance.
- Monthly Spending representation.
- Chart Expense by Category.
- Chart có legend và tooltip.
- Income vs Expense visualization phù hợp.
- Budget Status section.
- Over-budget warning rõ bằng icon + text + color.
- Recent transactions chỉ là tiện ích phụ nếu cần.
- Add new expense mở U05.
- Expenses sidebar mở U03.
- Reports sidebar mở U13.
- Budgets sidebar mở U11.
## 8. U03 — Expense List
- Header Expenses.
- Button Add Expense.
- Search input.
- Filter Date.
- Filter Category.
- Filter Amount.
- Clear filters.
- Data table.
- Column Expense Name.
- Column Category.
- Column Amount.
- Column Date.
- Note indicator.
- Attachment indicator.
- Actions column.
- Pagination.
- Click record mở U04 Expense Detail.
- Edit mở U06.
- Delete mở confirmation dialog.
- Add Expense mở U05.
- Có loading state.
- Có empty state.
- Có no-results state.
- Có error state.

## 9. U04 — Expense Detail
- Breadcrumb Expenses > Expense Detail.
- Expense Name.
- Amount.
- Date.
- Category.
- Note.
- Attachment.
- Image attachment có thumbnail khi phù hợp.
- File attachment có icon/name.
- Button Edit.
- Button Delete.
- Back về U03.
- Edit mở U06.
- Delete phải confirmation.

## 10. U05 — Create Expense
- Header Add Expense.
- Expense Name input.
- Amount/Currency input.
- Date input.
- Category select.
- Note textarea.
- Attachment upload.
- Cancel button.
- Create button.
- Field validation.
- Attachment selected/uploading/error states.
- Submit loading state.
- Success feedback.
- Cancel quay U03.

## 11. U06 — Edit Expense
- Reuse Expense Form.
- Pre-fill dữ liệu hiện tại.
- Header Edit Expense.
- Save Changes.
- Cancel.
- Validation.
- Save thành công về Detail/List.
## 12. U07 — Income List
- Header Incomes.
- Button Add Income.
- Search.
- Filter Month.
- Filter Income Type.
- Clear filters.
- Table/list Income.
- Source/Name.
- Type.
- Amount.
- Date.
- Actions.
- Pagination.
- Edit action.
- Delete confirmation.
- Loading state.
- Empty state.
- Error state.
- Add Income mở U08.

## 13. U08 — Create/Edit Income
- Form Income riêng.
- Source/Name.
- Amount.
- Date.
- Type.
- Note nếu schema hỗ trợ.
- Cancel.
- Create/Save.
- Validation.
- Create và Edit reuse cùng form pattern.
- Không invent field nghiệp vụ chưa được ERD/SRS xác nhận.

## 14. U09 — Category List
- Header Categories.
- Button Add Category.
- Danh sách category dạng card/list hybrid.
- Category icon.
- Name.
- Description.
- Edit.
- Delete.
- Delete confirmation.
- Add/Edit mở U10.
- Empty state.

## 15. U10 — Create/Edit Category
- Icon picker.
- Name input.
- Description.
- Cancel.
- Save.
- Validation.
- Edit mode pre-fill.
## 16. U11 — Budget List
- Header Budgets.
- Button Add Budget.
- Hiển thị theo Month hoặc Category.
- Category.
- Budget Amount.
- Spent Amount.
- Remaining Amount.
- Progress Bar.
- Status.
- Edit.
- Delete.
- Over-budget state rõ.
- Không chỉ dùng màu để báo trạng thái.
- Add/Edit mở U12.
- Empty state.
- Loading state.

## 17. U12 — Create/Edit Budget
- Form riêng.
- Month selector.
- Category selector.
- Budget Amount.
- Cancel.
- Save.
- Validation.
- Edit mode pre-fill.
- Không invent business rule chưa được xác nhận.

## 18. U13 — Reports & Analytics
- Header Reports & Analytics.
- Period selector Month.
- Period selector Quarter.
- Period selector Year.
- Expense Distribution by Category chart.
- Income vs Expense chart.
- Spending Trend Over Time chart.
- Chart title.
- Legend.
- Tooltip.
- Loading state.
- Empty state.
- Error state.
- Currency format nhất quán.
## 19. U14 — Import Data
- Header Import Data.
- Entity selector.
- Chỉ expose entity User được phép quản lý.
- CSV upload/drop zone.
- Selected file state.
- Invalid file state.
- Validating state.
- Importing state.
- Completed state.
- Failed state.
- Preview chỉ khi backend hỗ trợ.
- Confirm Import button.

## 20. U15 — Export Data
- Header Export Data.
- Data Type selector.
- Filter/range nếu API hỗ trợ.
- Export CSV button.
- Generating/loading state.
- Error feedback.
- Không invent format ngoài CSV.

## 21. A01 — Admin Login
- Admin Login riêng.
- Có label/branding Administration.
- Email.
- Password.
- Sign in.
- Validation.
- Error.
- Loading.
- Thành công mở A02.

## 22. A02 — Admin Dashboard
- Header Administration Dashboard.
- Admin sidebar.
- Requirement chưa định nghĩa KPI cụ thể.
- Không tự invent nhiều business metrics.
- Có thể dùng quick navigation cards.
- Có thể có basic system overview dạng placeholder.
- Giữ khả năng mở rộng.
## 23. A03 — Admin User List
- Header Users.
- Add User.
- Filter Status.
- Table.
- Name.
- Email.
- Role.
- Active Status.
- Actions.
- Pagination.
- Click user mở A04.
- Add/Edit mở A05.
- Delete confirmation.
- Loading/empty/error states.

## 24. A04 — Admin User Detail
- Breadcrumb Users > User Detail.
- Name.
- Email.
- Role.
- Active Status.
- Edit.
- Delete.
- Back.
- Không thêm profile data ngoài requirement.

## 25. A05 — Create/Edit User
- Name input.
- Email input.
- Role select.
- Active Status control.
- Cancel.
- Create/Save.
- Required validation.
- Email validation.
- Edit mode pre-fill.

## 26. A06 — Admin Category List
- Header Categories.
- Add Category.
- Table/list.
- Name.
- Description.
- Type.
- Type Expense hoặc Income.
- Edit.
- Delete.
- Loading/empty/error.
- Add/Edit mở A07.

## 27. A07 — Create/Edit Admin Category
- Name.
- Description.
- Type selector Expense/Income.
- Cancel.
- Save.
- Validation.
- Edit mode pre-fill.
## 28. A08 — Budget Template List
- Header Budget Templates.
- Add Template.
- Name.
- Month.
- Default categories summary.
- Edit.
- Delete.
- Loading/empty/error.
- Add/Edit mở A09.

## 29. A09 — Create/Edit Budget Template
- Name.
- Month.
- Repeatable category rows.
- Mỗi row có Category.
- Mỗi row có Default Amount.
- Remove Row.
- Add Category Row.
- Cancel.
- Save.
- Validation.
- Layout phải xử lý tốt nhiều rows.

## 30. A10 — System Expense List
- Header System Expenses.
- Dữ liệu tất cả users.
- Filter User.
- Filter Category.
- Filter Date Range.
- Clear Filters.
- Table.
- User column.
- Expense Name.
- Category.
- Amount.
- Date.
- Actions.
- Pagination.
- Click record mở A11.
- Edit.
- Delete confirmation.
- Ownership phải rõ.

## 31. A11 — System Expense Detail/Edit
- Hiển thị User sở hữu record.
- Expense Name.
- Amount.
- Date.
- Category.
- Note.
- Attachment.
- Edit.
- Delete.
- Back.
- Edit reuse Expense form theo Admin context.
## 32. A12 — System Income List
- Header System Incomes.
- Filter User.
- Filter Date Range.
- Clear Filters.
- Table.
- User.
- Source/Name.
- Type nếu schema có.
- Amount.
- Date.
- Actions.
- Pagination.
- Edit.
- Delete confirmation.
- Loading/empty/error.

## 33. A13 — System Income Edit
- Form edit Income.
- Hiển thị rõ owner/user.
- Reuse Income form.
- Save.
- Cancel.
- Validation.
- Không invent field chưa xác nhận.

## 34. A14 — Activity Logs
- Header Activity Logs.
- Table.
- Time.
- Action.
- Actor.
- Description.
- Action badge vừa phải.
- Log Login.
- Log Logout.
- Log Create.
- Log Update.
- Log Delete.
- Delete Log action.
- Delete confirmation.
- Pagination nếu implementation hỗ trợ.
- Filter/search chỉ khi API hỗ trợ.

## 35. A15 — Admin Import
- Entity selector.
- User.
- Expense.
- Income.
- Category.
- Budget.
- CSV upload.
- Validation state.
- Confirm import.
- Progress/result.
- Failed state.
- Bulk import warning.

## 36. A16 — Admin Export
- Data Type selector.
- User.
- Expense.
- Income.
- Category.
- Budget.
- Filters nếu backend hỗ trợ.
- Export CSV.
- Loading/error state.
## 37. Shared Components
- Button: Primary, Secondary, Ghost, Danger.
- Button states: Default, Hover, Focus, Loading, Disabled.
- Input.
- Currency Input.
- Textarea.
- Select.
- Searchable Combobox khi cần.
- Checkbox/Radio/Switch khi phù hợp.
- Badge.
- Avatar.
- Tooltip.
- Sidebar.
- Sidebar Item.
- Topbar.
- Breadcrumb.
- Pagination.
- Stat Card.
- Data Table.
- Filter Bar.
- Progress Bar.
- Chart Card.
- Modal.
- Confirm Dialog.
- Toast.
- Empty State.
- Error State.
- Skeleton.
- File Upload.
- Expense Form.
- Income Form.
- Budget Card.
- Category item/chip.
- Activity Log row.

## 38. Navigation & Prototype Interaction
- Dashboard → U02.
- Expenses → U03.
- Incomes → U07.
- Categories → U09.
- Budgets → U11.
- Reports → U13.
- Import/Export → U14/U15.
- Add Expense → U05.
- Expense row → U04.
- Expense Edit → U06.
- Expense Delete → Confirm Dialog → U03.
- Add Income → U08.
- Add Category → U10.
- Add Budget → U12.
- Admin Users → A03.
- Admin User row → A04.
- Admin Add/Edit User → A05.
- Admin Categories → A06.
- Admin Budget Templates → A08.
- Admin Expenses → A10.
- Admin Incomes → A12.
- Admin Activity Logs → A14.
- Admin Import/Export → A15/A16.
- Back/Cancel quay về page hợp lý.
- Button chính không được chỉ mang tính trang trí.
## 39. Data Table Rules
- Header rõ.
- Amount căn phải.
- Actions ở cột cuối.
- Row hover nhẹ.
- Pagination dưới table.
- Filter trên table.
- Có result count nếu phù hợp.
- Loading skeleton.
- Empty state.
- Error state.
- Text dài truncate/wrap hợp lý.
- Destructive action dùng danger.
- Mobile User table chuyển list/card khi hợp lý.

## 40. Form Rules
- Label luôn hiển thị.
- Placeholder không thay label.
- Required field rõ.
- Error gần field.
- Form dài chia section.
- Save/Create là primary.
- Cancel là secondary.
- Submit loading chống double-click.
- Disabled state rõ.
- File upload có state.
- Currency input dễ đọc.
- Create/Edit reuse pattern.

## 41. Feedback States
- Loading.
- Empty.
- Error.
- Success.
- No-search-results khác empty database.
- Create success feedback.
- Update success feedback.
- Delete success feedback.
- Không show raw technical error.
- Destructive action phải confirmation.

## 42. Accessibility
- Hướng tới WCAG AA.
- Focus visible.
- Form có label.
- Error message rõ.
- Icon button có accessible meaning.
- Không dùng màu làm tín hiệu duy nhất.
- Warning có icon + text.
- Keyboard navigation khả thi.
- Touch target khoảng 44px.
- Heading hierarchy rõ.
- Chart có legend/label.
## 43. Figma Organization
- Không dồn toàn app vào một frame.
- Page 00 — Cover.
- Page 01 — Foundations.
- Page 02 — Components.
- Page 03 — Patterns.
- Page 04 — User Flows.
- Page 05 — User Screens.
- Page 06 — Admin Flows.
- Page 07 — Admin Screens.
- Page 08 — Responsive.
- Page 09 — Prototype.
- Dùng Auto Layout.
- Dùng reusable components.
- Dùng variants.
- Dùng variables/tokens nếu có thể.
- Naming: USER / Dashboard / Desktop.
- Naming: USER / Expenses / List / Desktop.
- Naming: USER / Expenses / Create / Desktop.
- Naming: ADMIN / Users / List / Desktop.
- Naming: ADMIN / Activity Logs / Desktop.

## 44. Required Screen Inventory
- U01 User Login.
- U02 User Dashboard.
- U03 Expense List.
- U04 Expense Detail.
- U05 Create Expense.
- U06 Edit Expense.
- U07 Income List.
- U08 Create/Edit Income.
- U09 Category List.
- U10 Create/Edit Category.
- U11 Budget List.
- U12 Create/Edit Budget.
- U13 Reports & Analytics.
- U14 Import Data.
- U15 Export Data.
- A01 Admin Login.
- A02 Admin Dashboard.
- A03 User List.
- A04 User Detail.
- A05 Create/Edit User.
- A06 Admin Category List.
- A07 Create/Edit Admin Category.
- A08 Budget Template List.
- A09 Create/Edit Budget Template.
- A10 System Expense List.
- A11 System Expense Detail/Edit.
- A12 System Income List.
- A13 System Income Edit.
- A14 Activity Logs.
- A15 Admin Import.
- A16 Admin Export.
## 45. Required Prototype Flows
- Login → User Dashboard.
- Dashboard → Add Expense.
- Add Expense → Save → Expense Detail/List.
- Expense List → Expense Detail.
- Expense Detail → Edit Expense.
- Expense Detail → Delete confirmation → Expense List.
- Sidebar → Income List.
- Sidebar → Categories.
- Sidebar → Budgets.
- Sidebar → Reports.
- Reports → Month/Quarter/Year.
- Admin Login → Admin Dashboard.
- Admin Dashboard/Sidebar → Users.
- Users → User Detail.
- User Detail → Edit User.
- Admin Sidebar → Budget Templates.
- Admin Sidebar → System Expenses.
- Admin Sidebar → System Incomes.
- Admin Sidebar → Activity Logs.
- Import/Export phải mở màn riêng.

## 46. Mock Data
- Không dùng Lorem ipsum cho toàn app.
- Dùng dữ liệu tài chính giả lập thực tế.
- Categories: Food & Dining, Transportation, Shopping.
- Categories: Entertainment, Utilities, Healthcare, Education.
- Transactions: Grocery shopping.
- Transactions: Electricity bill.
- Transactions: Monthly internet bill.
- Transactions: Grab transportation.
- Dùng tiền Việt Nam.
- Có amount nhỏ/lớn.
- Có tên dài.
- Có note trống/dài.
- Có attachment và không attachment.
## 47. Giới hạn nghiệp vụ
- Không invent business requirement ngoài specification.
- Income schema chi tiết chờ ERD/SRS nếu chưa chốt.
- Budget schema chi tiết chờ ERD/SRS nếu chưa chốt.
- Attachment size/type chờ backend/API.
- Admin Dashboard KPI chưa được định nghĩa.
- Near-budget threshold chưa được định nghĩa.
- CSV preview/error report chỉ dùng nếu backend hỗ trợ.
- Visual decision hợp lý được phép.
- Visual decision không được biến thành business rule.
- Component phải map được sang React/Storybook.
- Tránh component one-off không tái sử dụng.

## 48. Final Instruction for Gemini Stitch
- READ THIS ENTIRE FILE FIRST.
- CREATE A MULTI-SCREEN WEB APPLICATION, NOT A SINGLE DASHBOARD.
- Generate every screen listed in Required Screen Inventory.
- User area and Admin area must be separate.
- Every sidebar item must have a destination screen.
- Every important CRUD action must have its corresponding screen/dialog.
- Keep one shared Design System.
- Keep layouts and components consistent.
- Connect major screens using prototype/navigation interactions.
- Prioritize desktop first, while preserving responsive behavior.
- Make the result clean and suitable for export to Figma.
- Do not stop after generating Dashboard.
- Do not merge unrelated pages into one giant page.
- Before finishing, compare the result against the Required Screen Inventory.
- If any required screen is missing, CREATE IT before considering the design complete.
- The final result should resemble a real production SaaS/FinTech application.
